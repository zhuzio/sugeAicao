<?php
/**********************************************************\
|                                                          |
|                          hprose                          |
|                                                          |
| Official WebSite: http://www.hprose.com/                 |
|                   http://www.hprose.net/                 |
|                   http://www.hprose.org/                 |
|                                                          |
\**********************************************************/

/**********************************************************\
 *                                                        *
 * HproseIO.php                                           *
 *                                                        *
 * hprose io library for php5.                            *
 *                                                        *
 * LastModified: Nov 10, 2013                             *
 * Author: Ma Bingyao <andot@hprfc.com>                   *
 *                                                        *
\**********************************************************/

require_once('HproseTags.php');
require_once('HproseClassManager.php');
require_once('HproseReader.php');
require_once('HproseWriter.php');
require_once('HproseFormatter.php');

?>
